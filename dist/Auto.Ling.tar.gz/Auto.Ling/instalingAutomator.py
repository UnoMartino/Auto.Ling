from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep
import json


#declare variables
def variables():
    global usernames
    global passwords
    global driver
    global lastTwoWords

    usernames = []
    passwords = []
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("window-size=1920,1080")
    driver = webdriver.Chrome(executable_path="./chromedriver", options=options)
    lastTwoWords = []


# get secrets
def getSecrets():
    file = open("./secrets.txt", "r")
    secretsFile = file.readlines()
    file.close()
    for i in secretsFile:
        i = i.split(":")
        usernames.append(i[0])
        passwords.append(i[1])


def login(id):
    driver.get("https://instaling.pl/")
    assert "Insta.Ling" in driver.title
    loginButton = driver.find_element(By.CSS_SELECTOR, "#navbar > a.btn.navbar-profile.p-0.m-0.pr-2 > div.btn.btn-secondary.btn-login.d-none.d-sm-none.d-lg-block.mr-3")
    loginButton.click()
    username = driver.find_element(By.NAME, "log_email")
    username.clear()
    username.send_keys(usernames[id])
    password = driver.find_element(By.NAME, "log_password")
    password.clear()
    password.send_keys(passwords[id])
    loginButton = driver.find_element(By.CSS_SELECTOR, "#main-container > div:nth-child(3) > form > div > div:nth-child(3) > button")
    loginButton.click()


# save words
def saveWords():
    driver.get("https://instaling.pl/")
    button = driver.find_element(By.CSS_SELECTOR, "#navbar > a.btn.navbar-profile.p-0.m-0.pr-2 > div.login-img > div:nth-child(2) > img")
    button.click()
    button = driver.find_element(By.CSS_SELECTOR, "#student_panel > p:nth-child(15) > a")
    button.click()
    button = driver.find_element(By.CSS_SELECTOR, "#account_page > div > a:nth-child(2) > h4")
    button.click()
    button = driver.find_element(By.CSS_SELECTOR, "#show_words")
    button.click()

    rows = len(driver.find_elements(By.XPATH, '//*[@id="assigned_words"]/tr'))

    wordsTuple = []

    for r in range(2, rows+1):
        value = driver.find_element(By.XPATH, '//*[@id="assigned_words"]/tr['+str(r)+']/td['+str(1)+']').text
        germanWord = value  
        value = driver.find_element(By.XPATH, '//*[@id="assigned_words"]/tr['+str(r)+']/td['+str(2)+']').text
        polishWord = value
        wordsTuple.append({"germanWord": germanWord, "polishWord": polishWord})

    with open('words.json', 'w') as outfile:
        json.dump(wordsTuple, outfile)

    print(wordsTuple)

def doOneWord():
    # read words from json
    with open('words.json') as json_file:
        words = json.load(json_file)

    polishWord = driver.find_element(By.CSS_SELECTOR, "#question > div.caption > div.translations").text
    print("polishWord: ", polishWord)

    #log last two words in table
    if len(lastTwoWords) == 2:
        lastTwoWords.pop(0)
    lastTwoWords.append(polishWord)

    # check if last two words are the same and if so, delete first occurence from json and append it to the end
    if len(lastTwoWords) == 2:
        if lastTwoWords[0] == lastTwoWords[1]:
            for i in words:
                if i["polishWord"] == lastTwoWords[0]:
                    words.remove(i)
                    words.append(i)
                    break
            print("removed and appended")
            with open('words.json', 'w') as outfile:
                json.dump(words, outfile)

    for i in words:
        if i["polishWord"] == polishWord:
            germanWord = i["germanWord"]
            print("germanWord: ", germanWord)
            answer = driver.find_element(By.CSS_SELECTOR, "#answer")
            answer.send_keys(germanWord)
            answer.send_keys(Keys.RETURN)
            sleep(1)
            button = driver.find_element(By.CSS_SELECTOR, "#next_word")
            button.click()
            sleep(1)
            return
        
    print("not found")
    button = driver.find_element(By.CSS_SELECTOR, "#check > h4")
    button.click()
    sleep(1)
    germanWord = driver.find_element(By.CSS_SELECTOR, "#word").text
    print("germanWord: ", germanWord)
    appendWord(polishWord, germanWord)
    button = driver.find_element(By.CSS_SELECTOR, "#next_word")
    button.click()
    sleep(1)


def doSession():
    driver.get("https://instaling.pl/")
    button = driver.find_element(By.CSS_SELECTOR, "#navbar > a.btn.navbar-profile.p-0.m-0.pr-2 > div.login-img > div:nth-child(2) > img")
    button.click()
    button = driver.find_element(By.CSS_SELECTOR, "#student_panel > p:nth-child(9) > a")
    button.click()

    try:
        button = driver.find_element(By.CSS_SELECTOR, "#continue_session_button > h4")
        button.click()
        print("Continue session")
        sleep(1)
    except:
        print("New session")
        button = driver.find_element(By.CSS_SELECTOR, "#start_session_button > h4")
        button.click()
        sleep(1)

    while True:
        try: 
            doOneWord()
        except:
            break

def appendWord(polishWord, germanWord):
    json_file = open('words.json', "r")
    words = json.load(json_file)
    json_file.close()
    words.append({"germanWord": germanWord, "polishWord": polishWord})
    with open('words.json', 'w') as outfile:
        json.dump(words, outfile)


